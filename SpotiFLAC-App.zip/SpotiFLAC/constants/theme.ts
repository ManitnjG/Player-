// constants/theme.ts
export const Colors = {
  bg: '#080a0f',
  surface: '#0e1118',
  surface2: '#161b26',
  surface3: '#1e2535',
  border: 'rgba(255,255,255,0.07)',
  accent: '#00e5ff',
  accent2: '#7b61ff',
  gold: '#ffd166',
  text: '#e8eaf0',
  muted: '#5a6480',
  flac: '#00e5a0',
};

export const GradientSets = [
  ['#1a0533', '#330d5a', '#0d1a33'],
  ['#330a0a', '#1a0533', '#002233'],
  ['#002233', '#003322', '#1a3300'],
  ['#1a1a00', '#2d1a00', '#001a1a'],
  ['#00001a', '#001a33', '#1a0033'],
  ['#0d0d0d', '#1a0a1a', '#001a0d'],
];

export const SOURCES = ['Tidal', 'Qobuz', 'Amazon'];

export type Track = {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  year: number;
  format: 'FLAC' | 'HiRes' | 'MQA';
  bitDepth: string;
  sampleRate: string;
  source: string;
  emoji: string;
  gradientIndex: number;
};

export const DEMO_TRACKS: Track[] = [
  { id: '1', title: 'Midnight Architecture', artist: 'Jon Hopkins', album: 'Ritual', duration: '4:12', year: 2024, format: 'FLAC', bitDepth: '24-bit', sampleRate: '96kHz', source: 'Tidal', emoji: '🎹', gradientIndex: 1 },
  { id: '2', title: 'Neon Hymn', artist: 'Floating Points', album: 'Pharoah Sanders', duration: '6:44', year: 2023, format: 'HiRes', bitDepth: '32-bit', sampleRate: '192kHz', source: 'Qobuz', emoji: '🎷', gradientIndex: 2 },
  { id: '3', title: 'Retrograde', artist: 'James Blake', album: 'Overgrown', duration: '3:53', year: 2023, format: 'FLAC', bitDepth: '24-bit', sampleRate: '96kHz', source: 'Tidal', emoji: '🎸', gradientIndex: 0 },
  { id: '4', title: 'Sofia', artist: 'Clairo', album: 'Immunity', duration: '3:18', year: 2023, format: 'MQA', bitDepth: '24-bit', sampleRate: '48kHz', source: 'Tidal', emoji: '🎻', gradientIndex: 3 },
  { id: '5', title: 'Video Games', artist: 'Lana Del Rey', album: 'Born To Die', duration: '5:02', year: 2024, format: 'HiRes', bitDepth: '24-bit', sampleRate: '192kHz', source: 'Qobuz', emoji: '🌊', gradientIndex: 4 },
  { id: '6', title: 'BALD!', artist: 'JPEGMAFIA', album: 'LP!', duration: '2:49', year: 2024, format: 'FLAC', bitDepth: '24-bit', sampleRate: '96kHz', source: 'Amazon', emoji: '⚡', gradientIndex: 5 },
  { id: '7', title: 'Vaults of Heaven', artist: 'Jon Hopkins', album: 'Ritual', duration: '7:11', year: 2024, format: 'FLAC', bitDepth: '24-bit', sampleRate: '96kHz', source: 'Tidal', emoji: '🌌', gradientIndex: 1 },
  { id: '8', title: 'Last Bloom', artist: 'Rival Consoles', album: 'Persona', duration: '5:33', year: 2023, format: 'HiRes', bitDepth: '32-bit', sampleRate: '96kHz', source: 'Qobuz', emoji: '🌸', gradientIndex: 2 },
];

export const DEMO_ALBUMS = [
  { id: 'a1', title: 'Ritual', artist: 'Jon Hopkins', emoji: '🎹', gradientIndex: 1, format: 'FLAC', source: 'Tidal', tracks: 12 },
  { id: 'a2', title: 'Solar Power', artist: 'Lorde', emoji: '🌞', gradientIndex: 2, format: 'HiRes', source: 'Qobuz', tracks: 14 },
  { id: 'a3', title: 'Colour in Anything', artist: 'James Blake', emoji: '🎨', gradientIndex: 0, format: 'FLAC', source: 'Tidal', tracks: 17 },
  { id: 'a4', title: 'Immunity', artist: 'Clairo', emoji: '🦋', gradientIndex: 3, format: 'MQA', source: 'Tidal', tracks: 11 },
  { id: 'a5', title: 'Ultraviolence', artist: 'Lana Del Rey', emoji: '🌹', gradientIndex: 4, format: 'HiRes', source: 'Qobuz', tracks: 10 },
  { id: 'a6', title: 'LP!', artist: 'JPEGMAFIA', emoji: '⚡', gradientIndex: 5, format: 'FLAC', source: 'Amazon', tracks: 18 },
];
