// app/_layout.tsx
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { PlayerProvider } from '../hooks/usePlayer';

export default function RootLayout() {
  return (
    <PlayerProvider>
      <StatusBar style="light" backgroundColor="#080a0f" />
      <Stack screenOptions={{ headerShown: false }} />
    </PlayerProvider>
  );
}
