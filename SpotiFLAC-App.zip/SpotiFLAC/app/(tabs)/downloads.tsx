// app/(tabs)/downloads.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../../constants/theme';
import DownloadQueue from '../../components/DownloadQueue';
import { usePlayer } from '../../hooks/usePlayer';

export default function DownloadsScreen() {
  const { downloadQueue } = usePlayer();
  const done = downloadQueue.filter(q => q.done).length;
  const active = downloadQueue.filter(q => !q.done).length;

  return (
    <View style={styles.container}>
      {/* Header stats */}
      {downloadQueue.length > 0 && (
        <View style={styles.statsRow}>
          <View style={styles.stat}>
            <Text style={[styles.statVal, { color: Colors.accent }]}>{active}</Text>
            <Text style={styles.statLabel}>Downloading</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.stat}>
            <Text style={[styles.statVal, { color: Colors.flac }]}>{done}</Text>
            <Text style={styles.statLabel}>Complete</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.stat}>
            <Text style={styles.statVal}>{downloadQueue.length}</Text>
            <Text style={styles.statLabel}>Total</Text>
          </View>
        </View>
      )}
      <DownloadQueue />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  statsRow: {
    flexDirection: 'row', margin: 16, backgroundColor: Colors.surface,
    borderRadius: 12, borderWidth: 1, borderColor: Colors.border,
    paddingVertical: 14,
  },
  stat: { flex: 1, alignItems: 'center' },
  statVal: { fontSize: 22, fontWeight: '800', color: Colors.text },
  statLabel: { fontSize: 10, color: Colors.muted, textTransform: 'uppercase', letterSpacing: 1, marginTop: 2 },
  divider: { width: 1, backgroundColor: Colors.border },
});
