// app/(tabs)/library.tsx
import React from 'react';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Colors, DEMO_TRACKS } from '../../constants/theme';
import TrackRow from '../../components/TrackRow';
import { usePlayer } from '../../hooks/usePlayer';

export default function LibraryScreen() {
  const { tracks } = usePlayer();

  const sections = [
    { title: 'Recently Played', data: tracks.slice(0, 4) },
    { title: 'Your Liked Tracks', data: tracks.slice(2, 6) },
  ];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Source filter */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.sourceRow}>
        {[{ label: 'All', active: true }, { label: '⬛ Tidal' }, { label: '🔵 Qobuz' }, { label: '🟠 Amazon' }].map(s => (
          <TouchableOpacity key={s.label} style={[styles.sourceChip, s.active && styles.activeChip]}>
            <Text style={[styles.sourceChipText, s.active && styles.activeChipText]}>{s.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {sections.map(section => (
        <View key={section.title} style={styles.section}>
          <Text style={styles.sectionTitle}>{section.title}</Text>
          <View style={styles.trackList}>
            {section.data.map((track, i) => (
              <TrackRow key={track.id + i} track={track} index={i} list={section.data} />
            ))}
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: 16, paddingBottom: 40, gap: 8 },
  sourceRow: { gap: 8, marginBottom: 16, paddingRight: 16 },
  sourceChip: {
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20,
    borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.surface2,
  },
  activeChip: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  sourceChipText: { fontSize: 12, fontWeight: '600', color: Colors.muted },
  activeChipText: { color: '#000' },
  section: { marginBottom: 24 },
  sectionTitle: { fontSize: 16, fontWeight: '800', color: Colors.text, marginBottom: 12 },
  trackList: { gap: 2 },
});
