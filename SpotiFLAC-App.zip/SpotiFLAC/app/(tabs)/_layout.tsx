// app/(tabs)/_layout.tsx
import React from 'react';
import { Tabs } from 'expo-router';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '../../constants/theme';
import MiniPlayer from '../../components/MiniPlayer';
import FullPlayer from '../../components/FullPlayer';

function TabIcon({ emoji, label, focused }: { emoji: string; label: string; focused: boolean }) {
  return (
    <View style={[tabStyles.icon, focused && tabStyles.iconFocused]}>
      <Text style={tabStyles.emoji}>{emoji}</Text>
      <Text style={[tabStyles.label, focused && tabStyles.labelFocused]}>{label}</Text>
    </View>
  );
}

const tabStyles = StyleSheet.create({
  icon: { alignItems: 'center', gap: 2, paddingTop: 4 },
  iconFocused: {},
  emoji: { fontSize: 20 },
  label: { fontSize: 9, color: Colors.muted, fontWeight: '600', letterSpacing: 0.5 },
  labelFocused: { color: Colors.accent },
});

export default function TabLayout() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.bg }} edges={['top']}>
      <View style={{ flex: 1 }}>
        <Tabs
          screenOptions={{
            headerStyle: { backgroundColor: Colors.surface, shadowColor: 'transparent', elevation: 0 },
            headerTitleStyle: { color: Colors.text, fontSize: 18, fontWeight: '800' },
            headerTintColor: Colors.text,
            tabBarStyle: {
              backgroundColor: Colors.surface,
              borderTopColor: Colors.border,
              borderTopWidth: 1,
              height: 60,
              paddingBottom: 8,
            },
            tabBarShowLabel: false,
          }}
        >
          <Tabs.Screen
            name="index"
            options={{
              title: 'SpotiFLAC',
              headerTitle: () => (
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <View style={hStyles.logoIcon}><Text style={{ fontSize: 13, fontWeight: '900', color: '#000' }}>SF</Text></View>
                  <Text style={hStyles.logoText}>Spoti<Text style={{ color: Colors.accent }}>FLAC</Text></Text>
                  <View style={hStyles.badge}><Text style={hStyles.badgeText}>LOSSLESS</Text></View>
                </View>
              ),
              tabBarIcon: ({ focused }) => <TabIcon emoji="🏠" label="Home" focused={focused} />,
            }}
          />
          <Tabs.Screen
            name="search"
            options={{
              title: 'Search',
              tabBarIcon: ({ focused }) => <TabIcon emoji="🔍" label="Search" focused={focused} />,
            }}
          />
          <Tabs.Screen
            name="library"
            options={{
              title: 'Library',
              tabBarIcon: ({ focused }) => <TabIcon emoji="💿" label="Library" focused={focused} />,
            }}
          />
          <Tabs.Screen
            name="downloads"
            options={{
              title: 'Downloads',
              tabBarIcon: ({ focused }) => <TabIcon emoji="⬇" label="Downloads" focused={focused} />,
            }}
          />
        </Tabs>

        {/* Mini Player sits above tab bar */}
        <MiniPlayer />

        {/* Full Player Modal */}
        <FullPlayer />
      </View>
    </SafeAreaView>
  );
}

const hStyles = StyleSheet.create({
  logoIcon: {
    width: 28, height: 28, borderRadius: 7,
    backgroundColor: Colors.accent, alignItems: 'center', justifyContent: 'center',
  },
  logoText: { fontSize: 16, fontWeight: '800', color: Colors.text },
  badge: { backgroundColor: Colors.flac, paddingHorizontal: 5, paddingVertical: 1, borderRadius: 3 },
  badgeText: { fontSize: 8, fontWeight: '800', color: '#000', letterSpacing: 1 },
});
