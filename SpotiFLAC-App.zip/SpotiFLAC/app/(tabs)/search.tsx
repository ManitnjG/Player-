// app/(tabs)/search.tsx
import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, FlatList, ActivityIndicator, Keyboard,
} from 'react-native';
import { usePlayer } from '../../hooks/usePlayer';
import { Colors, Track, GradientSets } from '../../constants/theme';
import TrackRow from '../../components/TrackRow';
import FormatBadge from '../../components/FormatBadge';

const FORMATS: ('FLAC' | 'HiRes' | 'MQA')[] = ['FLAC', 'HiRes', 'MQA'];
const SOURCES = ['Tidal', 'Qobuz', 'Amazon'];

export default function SearchScreen() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searched, setSearched] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { tracks, setTracks } = usePlayer();

  const doSearch = async (q: string) => {
    if (!q.trim()) return;
    Keyboard.dismiss();
    setLoading(true);
    setError('');
    setSearched(true);

    try {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1200,
          system: `You are a music search engine for SpotiFLAC, a lossless music app. When given a search query, return exactly 10 realistic music tracks as a JSON array.
Each track object must have: id (unique string), title, artist, album, duration (e.g. "3:42"), year (number), format ("FLAC" | "HiRes" | "MQA"), bitDepth (e.g. "24-bit"), sampleRate (e.g. "96kHz"), source ("Tidal" | "Qobuz" | "Amazon"), genre, emoji (single relevant music emoji), gradientIndex (number 0-5).
Return ONLY the raw JSON array. No markdown, no explanation, no backticks.`,
          messages: [{ role: 'user', content: `Search: "${q}"` }],
        }),
      });

      const data = await resp.json();
      const raw = data.content?.map((b: any) => b.text || '').join('') ?? '';
      const clean = raw.replace(/```json|```/g, '').trim();
      const parsed: Track[] = JSON.parse(clean);

      // Merge into global track list for playback
      const newTracks = parsed.filter(t => !tracks.find(e => e.id === t.id));
      setTracks([...tracks, ...newTracks]);
      setResults(parsed);
    } catch (e) {
      setError('Search failed. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (text: string) => {
    setQuery(text);
    if (timerRef.current) clearTimeout(timerRef.current);
    if (text.trim().length > 2) {
      timerRef.current = setTimeout(() => doSearch(text), 700);
    }
    if (!text) { setResults([]); setSearched(false); }
  };

  return (
    <View style={styles.container}>
      {/* Search bar */}
      <View style={styles.searchBar}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.input}
          value={query}
          onChangeText={handleChange}
          onSubmitEditing={() => doSearch(query)}
          placeholder="Artist, track, album, genre…"
          placeholderTextColor={Colors.muted}
          returnKeyType="search"
          autoCorrect={false}
        />
        {query.length > 0 && (
          <TouchableOpacity onPress={() => { setQuery(''); setResults([]); setSearched(false); }}>
            <Text style={styles.clearBtn}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Suggestions chips */}
      {!searched && (
        <View style={styles.suggestions}>
          <Text style={styles.suggestLabel}>Try searching:</Text>
          <View style={styles.suggestChips}>
            {['Radiohead', 'jazz FLAC', 'ambient 24bit', 'Post Malone', 'classical HiRes', 'lo-fi'].map(s => (
              <TouchableOpacity key={s} style={styles.suggestChip} onPress={() => { setQuery(s); doSearch(s); }}>
                <Text style={styles.suggestChipText}>{s}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.suggestLabel} style={{ marginTop: 20 }}>Filter by format:</Text>
          <View style={styles.suggestChips}>
            {FORMATS.map(f => (
              <TouchableOpacity key={f} style={styles.suggestChip} onPress={() => { setQuery(f); doSearch(f + ' music'); }}>
                <FormatBadge format={f} />
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* Loading */}
      {loading && (
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={Colors.accent} />
          <Text style={styles.loadingText}>Searching across Tidal, Qobuz & Amazon…</Text>
        </View>
      )}

      {/* Error */}
      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      {/* Results */}
      {!loading && results.length > 0 && (
        <FlatList
          data={results}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.resultsList}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <Text style={styles.resultsHeader}>{results.length} results for "{query}"</Text>
          }
          renderItem={({ item, index }) => (
            <TrackRow track={item} index={index} list={results} />
          )}
        />
      )}

      {/* No results */}
      {!loading && searched && results.length === 0 && !error && (
        <View style={styles.noResults}>
          <Text style={styles.noResultsIcon}>🎵</Text>
          <Text style={styles.noResultsText}>No results found for "{query}"</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    margin: 16, backgroundColor: Colors.surface2,
    borderWidth: 1, borderColor: Colors.border, borderRadius: 12,
    paddingHorizontal: 14,
  },
  searchIcon: { fontSize: 16 },
  input: {
    flex: 1, paddingVertical: 12, color: Colors.text,
    fontSize: 14, fontWeight: '500',
  },
  clearBtn: { fontSize: 14, color: Colors.muted, padding: 4 },
  suggestions: { paddingHorizontal: 16, gap: 10 },
  suggestLabel: { fontSize: 11, color: Colors.muted, textTransform: 'uppercase', letterSpacing: 1.5, fontWeight: '700' },
  suggestChips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  suggestChip: {
    backgroundColor: Colors.surface2, borderWidth: 1, borderColor: Colors.border,
    borderRadius: 20, paddingHorizontal: 14, paddingVertical: 7,
  },
  suggestChipText: { fontSize: 12, color: Colors.text, fontWeight: '600' },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 16 },
  loadingText: { fontSize: 13, color: Colors.muted, textAlign: 'center' },
  errorText: { color: '#ff6b6b', textAlign: 'center', padding: 20, fontSize: 13 },
  resultsList: { paddingHorizontal: 16, paddingBottom: 40 },
  resultsHeader: { fontSize: 12, color: Colors.muted, marginBottom: 12, fontFamily: 'monospace' },
  noResults: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  noResultsIcon: { fontSize: 40 },
  noResultsText: { fontSize: 14, color: Colors.muted },
});
