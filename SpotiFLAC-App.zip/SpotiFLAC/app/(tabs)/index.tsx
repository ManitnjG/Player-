// app/(tabs)/index.tsx
import React from 'react';
import {
  ScrollView, View, Text, TouchableOpacity,
  StyleSheet, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { usePlayer } from '../../hooks/usePlayer';
import { Colors, DEMO_ALBUMS, DEMO_TRACKS, GradientSets } from '../../constants/theme';
import TrackArt from '../../components/TrackArt';
import TrackRow from '../../components/TrackRow';
import FormatBadge from '../../components/FormatBadge';

const { width: W } = Dimensions.get('window');

function StatChip({ value, label, color }: { value: string; label: string; color?: string }) {
  return (
    <View style={styles.statChip}>
      <Text style={[styles.statValue, color ? { color } : {}]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

export default function HomeScreen() {
  const { playTrack, tracks } = usePlayer();

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

      {/* Stats bar */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.statsScroll} contentContainerStyle={styles.statsRow}>
        <StatChip value="FLAC" label="Format" color={Colors.flac} />
        <StatChip value="24-bit" label="Bit Depth" />
        <StatChip value="96kHz" label="Sample Rate" />
        <StatChip value="3" label="Sources" color={Colors.accent} />
        <StatChip value="∞" label="No Limit" />
      </ScrollView>

      {/* Hero banner */}
      <LinearGradient colors={['#0d1f3c', '#1a0a2e', '#0a1a1a']} style={styles.hero}>
        <LinearGradient
          colors={['transparent', 'rgba(0,229,255,0.07)', 'transparent']}
          start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }}
          style={StyleSheet.absoluteFill}
        />
        <TrackArt emoji="🎼" gradientIndex={0} size={90} borderRadius={12} />
        <View style={styles.heroInfo}>
          <Text style={styles.heroEyebrow}>Featured · Tidal</Text>
          <Text style={styles.heroTitle}>Lossless Dreams</Text>
          <Text style={styles.heroArtist}>Washed Out · 2024 · 12 tracks</Text>
          <View style={styles.heroActions}>
            <TouchableOpacity style={styles.heroPlayBtn} onPress={() => playTrack(DEMO_TRACKS[0])}>
              <Text style={styles.heroPlayIcon}>▶</Text>
            </TouchableOpacity>
            <View style={styles.heroMeta}>
              <Text style={styles.heroMetaLine}><Text style={{ color: Colors.flac }}>FLAC</Text> · 24-bit / 96kHz</Text>
              <Text style={styles.heroMetaLine}>No account required</Text>
            </View>
          </View>
        </View>
      </LinearGradient>

      {/* Albums */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>New Arrivals</Text>
        <Text style={styles.sectionMore}>See all →</Text>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.albumsRow}>
        {DEMO_ALBUMS.map(album => (
          <TouchableOpacity key={album.id} style={styles.albumCard}
            onPress={() => playTrack(DEMO_TRACKS.find(t => t.artist === album.artist) ?? DEMO_TRACKS[0])}
          >
            <TrackArt emoji={album.emoji} gradientIndex={album.gradientIndex} size={140} borderRadius={12} />
            <View style={styles.albumInfo}>
              <Text style={styles.albumTitle} numberOfLines={1}>{album.title}</Text>
              <Text style={styles.albumArtist} numberOfLines={1}>{album.artist}</Text>
              <View style={styles.albumTags}>
                <FormatBadge format={album.format} small />
                <View style={styles.srcTag}><Text style={styles.srcTagText}>{album.source}</Text></View>
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Hot Tracks */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Hot Tracks</Text>
        <Text style={styles.sectionMore}>See all →</Text>
      </View>

      <View style={styles.trackList}>
        {tracks.slice(0, 8).map((track, i) => (
          <TrackRow key={track.id} track={track} index={i} list={tracks} />
        ))}
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { padding: 16, paddingBottom: 40, gap: 4 },
  statsScroll: { marginBottom: 16 },
  statsRow: { gap: 10, paddingRight: 16 },
  statChip: {
    backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border,
    borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10, alignItems: 'center', minWidth: 80,
  },
  statValue: { fontSize: 16, fontWeight: '800', color: Colors.text, fontFamily: 'monospace' },
  statLabel: { fontSize: 9, color: Colors.muted, textTransform: 'uppercase', letterSpacing: 1, marginTop: 2 },
  hero: {
    borderRadius: 16, padding: 20, flexDirection: 'row', gap: 16,
    alignItems: 'center', marginBottom: 24, borderWidth: 1, borderColor: Colors.border,
    overflow: 'hidden',
  },
  heroInfo: { flex: 1 },
  heroEyebrow: { fontSize: 10, color: Colors.accent, letterSpacing: 2, textTransform: 'uppercase', fontWeight: '700', marginBottom: 4 },
  heroTitle: { fontSize: 20, fontWeight: '800', color: Colors.text, marginBottom: 2 },
  heroArtist: { fontSize: 12, color: Colors.muted, marginBottom: 12 },
  heroActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  heroPlayBtn: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.accent,
    alignItems: 'center', justifyContent: 'center',
  },
  heroPlayIcon: { fontSize: 16, color: '#000' },
  heroMeta: { flex: 1 },
  heroMetaLine: { fontSize: 10, color: Colors.muted, marginBottom: 2, fontFamily: 'monospace' },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8, marginBottom: 14 },
  sectionTitle: { fontSize: 18, fontWeight: '800', color: Colors.text },
  sectionMore: { fontSize: 11, color: Colors.muted, letterSpacing: 1 },
  albumsRow: { gap: 14, paddingRight: 16, marginBottom: 24 },
  albumCard: { width: 140 },
  albumInfo: { marginTop: 8, gap: 3 },
  albumTitle: { fontSize: 12, fontWeight: '700', color: Colors.text },
  albumArtist: { fontSize: 11, color: Colors.muted },
  albumTags: { flexDirection: 'row', gap: 5, marginTop: 3 },
  srcTag: {
    backgroundColor: 'rgba(255,255,255,0.05)', paddingHorizontal: 6, paddingVertical: 2,
    borderRadius: 4, borderWidth: 1, borderColor: Colors.border,
  },
  srcTagText: { fontSize: 9, color: Colors.muted, fontFamily: 'monospace' },
  trackList: { gap: 2 },
});
