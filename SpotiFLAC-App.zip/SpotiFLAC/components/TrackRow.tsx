// components/TrackRow.tsx
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Colors, Track } from '../constants/theme';
import TrackArt from './TrackArt';
import FormatBadge from './FormatBadge';
import { usePlayer } from '../hooks/usePlayer';

type Props = { track: Track; index: number; list: Track[] };

export default function TrackRow({ track, index, list }: Props) {
  const { playTrack, currentTrack, isPlaying, addToQueue } = usePlayer();
  const isActive = currentTrack?.id === track.id;

  return (
    <TouchableOpacity style={[styles.row, isActive && styles.activeRow]} onPress={() => playTrack(track, list)}>
      {/* Number / playing indicator */}
      <View style={styles.numWrap}>
        {isActive && isPlaying ? (
          <View style={styles.barsWrap}>
            {[0, 1, 2].map(i => <View key={i} style={[styles.bar, { animationDelay: `${i * 0.15}s` }]} />)}
          </View>
        ) : (
          <Text style={[styles.num, isActive && { color: Colors.accent }]}>{index + 1}</Text>
        )}
      </View>

      <TrackArt emoji={track.emoji} gradientIndex={track.gradientIndex} size={42} borderRadius={7} />

      <View style={styles.info}>
        <Text style={[styles.title, isActive && { color: Colors.accent }]} numberOfLines={1}>{track.title}</Text>
        <Text style={styles.artist} numberOfLines={1}>{track.artist}</Text>
      </View>

      <View style={styles.meta}>
        <FormatBadge format={track.format} small />
        <Text style={styles.khz}>{track.bitDepth.replace('-bit', '')}/{track.sampleRate.replace('kHz', '')}</Text>
      </View>

      <Text style={styles.dur}>{track.duration}</Text>

      <TouchableOpacity onPress={() => addToQueue(track)} hitSlop={8} style={styles.dlBtn}>
        <Text style={styles.dlIcon}>⬇</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingVertical: 8, paddingHorizontal: 4, borderRadius: 8,
  },
  activeRow: { backgroundColor: 'rgba(0,229,255,0.05)' },
  numWrap: { width: 24, alignItems: 'center' },
  num: { fontSize: 12, color: Colors.muted, fontFamily: 'monospace' },
  barsWrap: { flexDirection: 'row', alignItems: 'flex-end', gap: 2, height: 14 },
  bar: { width: 3, height: 10, backgroundColor: Colors.accent, borderRadius: 2 },
  info: { flex: 1, overflow: 'hidden' },
  title: { fontSize: 13, fontWeight: '600', color: Colors.text, marginBottom: 2 },
  artist: { fontSize: 11, color: Colors.muted },
  meta: { alignItems: 'flex-end', gap: 3 },
  khz: { fontSize: 9, color: Colors.muted, fontFamily: 'monospace' },
  dur: { fontSize: 11, color: Colors.muted, fontFamily: 'monospace', minWidth: 32, textAlign: 'right' },
  dlBtn: { padding: 4 },
  dlIcon: { fontSize: 14, color: Colors.muted },
});
