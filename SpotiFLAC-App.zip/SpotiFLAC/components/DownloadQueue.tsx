// components/DownloadQueue.tsx
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { usePlayer } from '../hooks/usePlayer';
import { Colors } from '../constants/theme';
import TrackArt from './TrackArt';
import FormatBadge from './FormatBadge';

export default function DownloadQueue() {
  const { downloadQueue } = usePlayer();

  if (downloadQueue.length === 0) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyIcon}>⬇</Text>
        <Text style={styles.emptyTitle}>No downloads yet</Text>
        <Text style={styles.emptyText}>Tap ⬇ on any track to download lossless FLAC</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.list}>
      {downloadQueue.map(item => (
        <View key={item.id} style={styles.item}>
          <TrackArt emoji={item.track.emoji} gradientIndex={item.track.gradientIndex} size={44} borderRadius={8} />
          <View style={styles.itemInfo}>
            <Text style={styles.itemTitle} numberOfLines={1}>{item.track.title}</Text>
            <View style={styles.itemMeta}>
              <FormatBadge format={item.track.format} small />
              <Text style={styles.itemArtist}> · {item.track.artist}</Text>
            </View>
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, {
                width: `${item.progress}%`,
                backgroundColor: item.done ? Colors.flac : Colors.accent,
              }]} />
            </View>
            <Text style={[styles.status, item.done && { color: Colors.flac }]}>
              {item.done ? `✓ Complete · ${item.track.format} ${item.track.bitDepth}/${item.track.sampleRate}` : `⬇ Downloading ${Math.round(item.progress)}%`}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 60 },
  emptyIcon: { fontSize: 40 },
  emptyTitle: { fontSize: 16, fontWeight: '700', color: Colors.text },
  emptyText: { fontSize: 12, color: Colors.muted, textAlign: 'center', paddingHorizontal: 40 },
  list: { padding: 16, gap: 10 },
  item: {
    flexDirection: 'row', gap: 12, alignItems: 'center',
    backgroundColor: Colors.surface2, borderRadius: 12, padding: 12,
    borderWidth: 1, borderColor: Colors.border,
  },
  itemInfo: { flex: 1, gap: 4 },
  itemTitle: { fontSize: 13, fontWeight: '600', color: Colors.text },
  itemMeta: { flexDirection: 'row', alignItems: 'center' },
  itemArtist: { fontSize: 11, color: Colors.muted },
  progressTrack: { height: 3, backgroundColor: Colors.surface3, borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: 3, borderRadius: 2, transition: 'width 0.3s' } as any,
  status: { fontSize: 10, color: Colors.muted, fontFamily: 'monospace' },
});
