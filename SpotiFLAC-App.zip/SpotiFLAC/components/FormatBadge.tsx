// components/FormatBadge.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../constants/theme';

type Props = { format: string; small?: boolean };

export default function FormatBadge({ format, small }: Props) {
  const cfg: Record<string, { bg: string; color: string }> = {
    FLAC:  { bg: 'rgba(0,229,160,0.12)', color: Colors.flac },
    HiRes: { bg: 'rgba(255,209,102,0.12)', color: Colors.gold },
    MQA:   { bg: 'rgba(123,97,255,0.12)', color: Colors.accent2 },
  };
  const c = cfg[format] ?? cfg.FLAC;
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }, small && styles.small]}>
      <Text style={[styles.text, { color: c.color }, small && styles.smallText]}>{format}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 7, paddingVertical: 2, borderRadius: 4,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)',
  },
  text: { fontFamily: 'monospace', fontSize: 9, fontWeight: '700' },
  small: { paddingHorizontal: 5, paddingVertical: 1 },
  smallText: { fontSize: 8 },
});
