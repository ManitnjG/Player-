// components/MiniPlayer.tsx
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { usePlayer } from '../hooks/usePlayer';
import { Colors, GradientSets } from '../constants/theme';
import TrackArt from './TrackArt';
import FormatBadge from './FormatBadge';

export default function MiniPlayer() {
  const { currentTrack, isPlaying, progress, togglePlay, nextTrack, prevTrack, setFullPlayerVisible } = usePlayer();

  if (!currentTrack) return null;

  return (
    <Pressable style={styles.container} onPress={() => setFullPlayerVisible(true)}>
      {/* Top accent line */}
      <LinearGradient
        colors={['transparent', Colors.accent, 'transparent']}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
        style={styles.accentLine}
      />

      {/* Progress bar */}
      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
      </View>

      <View style={styles.row}>
        {/* Art */}
        <TrackArt
          emoji={currentTrack.emoji}
          gradientIndex={currentTrack.gradientIndex}
          size={46}
          borderRadius={8}
        />

        {/* Info */}
        <View style={styles.info}>
          <Text style={styles.title} numberOfLines={1}>{currentTrack.title}</Text>
          <Text style={styles.artist} numberOfLines={1}>{currentTrack.artist}</Text>
          <View style={styles.badges}>
            <FormatBadge format={currentTrack.format} small />
            <Text style={styles.quality}> {currentTrack.bitDepth}/{currentTrack.sampleRate}</Text>
          </View>
        </View>

        {/* Controls */}
        <View style={styles.controls}>
          <TouchableOpacity onPress={prevTrack} hitSlop={10}>
            <Text style={styles.ctrlBtn}>⏮</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={togglePlay} style={styles.playBtn} hitSlop={6}>
            <Text style={styles.playIcon}>{isPlaying ? '⏸' : '▶'}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={nextTrack} hitSlop={10}>
            <Text style={styles.ctrlBtn}>⏭</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingBottom: 4,
  },
  accentLine: { height: 1, opacity: 0.4 },
  progressTrack: {
    height: 2, backgroundColor: Colors.surface3,
  },
  progressFill: {
    height: 2, backgroundColor: Colors.accent,
  },
  row: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 14, paddingVertical: 10, gap: 12,
  },
  info: { flex: 1, overflow: 'hidden' },
  title: { color: Colors.text, fontSize: 13, fontWeight: '700', marginBottom: 1 },
  artist: { color: Colors.muted, fontSize: 11, marginBottom: 4 },
  badges: { flexDirection: 'row', alignItems: 'center' },
  quality: { color: Colors.muted, fontSize: 9, fontFamily: 'monospace' },
  controls: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  ctrlBtn: { fontSize: 18, color: Colors.muted },
  playBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.text,
    alignItems: 'center', justifyContent: 'center',
  },
  playIcon: { fontSize: 14, color: '#000' },
});
