// components/FullPlayer.tsx
import React, { useRef } from 'react';
import {
  Modal, View, Text, TouchableOpacity, StyleSheet,
  Dimensions, PanResponder, Animated, ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { usePlayer } from '../hooks/usePlayer';
import { Colors, GradientSets } from '../constants/theme';
import TrackArt from './TrackArt';
import FormatBadge from './FormatBadge';

const { width: W } = Dimensions.get('window');

function fmt(s: number) {
  const m = Math.floor(s / 60);
  return `${m}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
}

export default function FullPlayer() {
  const {
    currentTrack, isPlaying, isShuffle, isRepeat,
    progress, position, duration, volume,
    togglePlay, nextTrack, prevTrack,
    toggleShuffle, toggleRepeat, seekTo, setVolume,
    fullPlayerVisible, setFullPlayerVisible, addToQueue,
  } = usePlayer();

  const progressBarRef = useRef<View>(null);
  const translateY = useRef(new Animated.Value(0)).current;

  const panResponder = PanResponder.create({
    onMoveShouldSetPanResponder: (_, g) => g.dy > 10,
    onPanResponderMove: (_, g) => {
      if (g.dy > 0) translateY.setValue(g.dy);
    },
    onPanResponderRelease: (_, g) => {
      if (g.dy > 120) {
        Animated.timing(translateY, { toValue: 800, duration: 250, useNativeDriver: true }).start(
          () => { setFullPlayerVisible(false); translateY.setValue(0); }
        );
      } else {
        Animated.spring(translateY, { toValue: 0, useNativeDriver: true }).start();
      }
    },
  });

  if (!currentTrack) return null;
  const gradColors = GradientSets[currentTrack.gradientIndex % GradientSets.length] as [string, string, string];

  return (
    <Modal visible={fullPlayerVisible} animationType="slide" transparent statusBarTranslucent>
      <Animated.View style={[styles.modal, { transform: [{ translateY }] }]} {...panResponder.panHandlers}>
        <LinearGradient colors={[gradColors[0], gradColors[1], Colors.bg]} style={styles.bg} />

        {/* Drag handle */}
        <View style={styles.handle} />

        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => setFullPlayerVisible(false)} hitSlop={14}>
            <Text style={styles.chevron}>⌄</Text>
          </TouchableOpacity>
          <View style={styles.headerCenter}>
            <Text style={styles.headerEyebrow}>Now Playing</Text>
            <Text style={styles.headerSource}>via {currentTrack.source}</Text>
          </View>
          <TouchableOpacity onPress={() => addToQueue(currentTrack)} hitSlop={14}>
            <Text style={styles.dlIcon}>⬇</Text>
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          {/* Album Art */}
          <View style={styles.artWrapper}>
            <TrackArt emoji={currentTrack.emoji} gradientIndex={currentTrack.gradientIndex} size={W - 80} borderRadius={22} />
          </View>

          {/* Track Info */}
          <View style={styles.trackInfo}>
            <View style={styles.trackInfoRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.trackTitle}>{currentTrack.title}</Text>
                <Text style={styles.trackArtist}>{currentTrack.artist} · {currentTrack.album}</Text>
              </View>
              <TouchableOpacity hitSlop={10}>
                <Text style={{ fontSize: 22, color: Colors.muted }}>♡</Text>
              </TouchableOpacity>
            </View>

            {/* Quality chips */}
            <View style={styles.chips}>
              <FormatBadge format={currentTrack.format} />
              <View style={styles.chip}><Text style={styles.chipText}>{currentTrack.bitDepth}</Text></View>
              <View style={styles.chip}><Text style={styles.chipText}>{currentTrack.sampleRate}</Text></View>
              <View style={styles.chip}><Text style={styles.chipText}>{currentTrack.year}</Text></View>
            </View>
          </View>

          {/* Waveform visual */}
          <View style={styles.waveform}>
            {Array.from({ length: 40 }, (_, i) => (
              <View
                key={i}
                style={[styles.waveBar, {
                  height: 4 + Math.abs(Math.sin(i * 0.45)) * 24,
                  opacity: (i / 40) < progress ? 1 : 0.3,
                  backgroundColor: (i / 40) < progress ? Colors.accent : Colors.surface3,
                }]}
              />
            ))}
          </View>

          {/* Seek bar */}
          <View style={styles.seekSection}>
            <TouchableOpacity
              style={styles.seekTrack}
              activeOpacity={1}
              onPress={(e) => {
                e.currentTarget.measure((_, __, w) => {
                  seekTo(e.nativeEvent.locationX / w);
                });
              }}
            >
              <View style={styles.seekBg}>
                <View style={[styles.seekFill, { width: `${progress * 100}%` }]} />
              </View>
            </TouchableOpacity>
            <View style={styles.timeRow}>
              <Text style={styles.time}>{fmt(position)}</Text>
              <Text style={styles.time}>{fmt(duration)}</Text>
            </View>
          </View>

          {/* Controls */}
          <View style={styles.controls}>
            <TouchableOpacity onPress={toggleShuffle} hitSlop={10}>
              <Text style={[styles.ctrlSm, isShuffle && { color: Colors.accent }]}>⇄</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={prevTrack} hitSlop={10}>
              <Text style={styles.ctrlMd}>⏮</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={togglePlay} style={styles.bigPlay}>
              <Text style={styles.bigPlayIcon}>{isPlaying ? '⏸' : '▶'}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={nextTrack} hitSlop={10}>
              <Text style={styles.ctrlMd}>⏭</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={toggleRepeat} hitSlop={10}>
              <Text style={[styles.ctrlSm, isRepeat && { color: Colors.accent }]}>↺</Text>
            </TouchableOpacity>
          </View>

          {/* Volume */}
          <View style={styles.volumeRow}>
            <Text style={styles.volIcon}>🔈</Text>
            <TouchableOpacity
              style={styles.volTrack}
              activeOpacity={1}
              onPress={(e) => {
                e.currentTarget.measure((_, __, w) => {
                  setVolume(e.nativeEvent.locationX / w);
                });
              }}
            >
              <View style={styles.volBg}>
                <View style={[styles.volFill, { width: `${volume * 100}%` }]} />
              </View>
            </TouchableOpacity>
            <Text style={styles.volIcon}>🔊</Text>
          </View>

          {/* Download button */}
          <TouchableOpacity style={styles.downloadBtn} onPress={() => addToQueue(currentTrack)}>
            <Text style={styles.downloadBtnText}>
              ⬇  Download {currentTrack.format} — {currentTrack.bitDepth}/{currentTrack.sampleRate}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </Animated.View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modal: { flex: 1, backgroundColor: Colors.bg },
  bg: { ...StyleSheet.absoluteFillObject, opacity: 0.9 },
  handle: {
    width: 40, height: 4, backgroundColor: Colors.surface3,
    borderRadius: 2, alignSelf: 'center', marginTop: 12,
  },
  header: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20,
    paddingVertical: 14, gap: 12,
  },
  chevron: { fontSize: 28, color: Colors.muted, lineHeight: 30 },
  headerCenter: { flex: 1, alignItems: 'center' },
  headerEyebrow: { fontSize: 11, color: Colors.muted, letterSpacing: 2, textTransform: 'uppercase' },
  headerSource: { fontSize: 12, color: Colors.text, fontWeight: '700', marginTop: 1 },
  dlIcon: { fontSize: 20, color: Colors.muted },
  content: { paddingHorizontal: 20, paddingBottom: 40, gap: 24 },
  artWrapper: {
    shadowColor: '#000', shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.7, shadowRadius: 30, elevation: 20,
  },
  trackInfo: { gap: 12 },
  trackInfoRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  trackTitle: { fontSize: 22, fontWeight: '800', color: Colors.text, marginBottom: 4 },
  trackArtist: { fontSize: 14, color: Colors.muted },
  chips: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  chip: {
    backgroundColor: 'rgba(255,255,255,0.06)', paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: 20, borderWidth: 1, borderColor: Colors.border,
  },
  chipText: { fontSize: 10, color: Colors.muted, fontFamily: 'monospace' },
  waveform: { flexDirection: 'row', alignItems: 'center', gap: 3, height: 32 },
  waveBar: { flex: 1, borderRadius: 2 },
  seekSection: { gap: 6 },
  seekTrack: { height: 20, justifyContent: 'center' },
  seekBg: { height: 4, backgroundColor: Colors.surface3, borderRadius: 2 },
  seekFill: { height: 4, backgroundColor: Colors.accent, borderRadius: 2 },
  timeRow: { flexDirection: 'row', justifyContent: 'space-between' },
  time: { fontSize: 11, color: Colors.muted, fontFamily: 'monospace' },
  controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 28 },
  ctrlSm: { fontSize: 22, color: Colors.muted },
  ctrlMd: { fontSize: 30, color: Colors.text },
  bigPlay: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: Colors.accent,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: Colors.accent, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.5, shadowRadius: 20,
    elevation: 10,
  },
  bigPlayIcon: { fontSize: 26, color: '#000' },
  volumeRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  volIcon: { fontSize: 14 },
  volTrack: { flex: 1, height: 20, justifyContent: 'center' },
  volBg: { height: 3, backgroundColor: Colors.surface3, borderRadius: 2 },
  volFill: { height: 3, backgroundColor: Colors.muted, borderRadius: 2 },
  downloadBtn: {
    backgroundColor: Colors.surface2, borderWidth: 1, borderColor: Colors.border,
    borderRadius: 12, paddingVertical: 14, alignItems: 'center',
  },
  downloadBtnText: { color: Colors.text, fontSize: 13, fontWeight: '700' },
});
