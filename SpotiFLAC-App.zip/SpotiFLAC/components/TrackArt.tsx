// components/TrackArt.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { GradientSets } from '../constants/theme';

type Props = {
  emoji: string;
  gradientIndex: number;
  size: number;
  borderRadius?: number;
};

export default function TrackArt({ emoji, gradientIndex, size, borderRadius = 10 }: Props) {
  const colors = GradientSets[gradientIndex % GradientSets.length] as [string, string, string];
  return (
    <LinearGradient
      colors={colors}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[styles.art, { width: size, height: size, borderRadius }]}
    >
      <Text style={{ fontSize: size * 0.42 }}>{emoji}</Text>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  art: { alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
});
