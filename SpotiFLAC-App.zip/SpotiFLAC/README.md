# SpotiFLAC Mobile 🎵

A lossless music app built with **Expo + React Native** for Android.  
AI-powered search · FLAC/HiRes/MQA · Mini Player · Full Player · Download Queue

---

## ✨ Features

- **Mini Player** — persistent bar above tab nav with progress, controls, quality badge
- **Full Screen Player** — swipe-down to dismiss, waveform visual, seek bar, volume
- **AI Search** — powered by Claude API, searches across Tidal, Qobuz & Amazon Music
- **Download Queue** — simulated FLAC download queue with progress bars
- **4 Screens**: Home, Search, Library, Downloads
- **Format Badges**: FLAC · HiRes · MQA with bit depth & sample rate
- **Dark theme** with gradient artwork

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- **Expo Go** app on your Android phone (from Play Store)

### 1. Install dependencies
```bash
cd SpotiFLAC
npm install
```

### 2. Start the dev server
```bash
npx expo start
```

### 3. Open on your phone
- Scan the QR code with **Expo Go** (Android)
- Or press `a` to launch on Android emulator

---

## 📱 Build APK (install directly on Android)

### Using EAS Build (recommended, free)
```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo account (free at expo.dev)
eas login

# Build APK
eas build --platform android --profile preview
```
This builds in the cloud (~10 min) and gives you a download link for the `.apk`.

### Local build (requires Android Studio + Java 17)
```bash
npx expo run:android
```

---

## 🔑 API Key Setup

The app calls the **Anthropic Claude API** for AI search.  
By default it uses the proxy built into Claude.ai artifacts.

For a standalone build, add your API key:

1. Create `constants/config.ts`:
```ts
export const ANTHROPIC_API_KEY = 'sk-ant-your-key-here';
```

2. Update the fetch header in `app/(tabs)/search.tsx`:
```ts
headers: {
  'Content-Type': 'application/json',
  'x-api-key': ANTHROPIC_API_KEY,
  'anthropic-version': '2023-06-01',
}
```

---

## 📂 Project Structure

```
SpotiFLAC/
├── app/
│   ├── _layout.tsx          # Root layout + PlayerProvider
│   └── (tabs)/
│       ├── _layout.tsx      # Tab bar + MiniPlayer + FullPlayer
│       ├── index.tsx        # Home screen
│       ├── search.tsx       # AI Search screen
│       ├── library.tsx      # Library screen
│       └── downloads.tsx    # Download queue screen
├── components/
│   ├── MiniPlayer.tsx       # Persistent bottom mini player
│   ├── FullPlayer.tsx       # Full screen player modal
│   ├── TrackRow.tsx         # Track list item
│   ├── TrackArt.tsx         # Gradient artwork component
│   ├── FormatBadge.tsx      # FLAC/HiRes/MQA badge
│   └── DownloadQueue.tsx    # Download queue list
├── hooks/
│   └── usePlayer.tsx        # Global player state context
├── constants/
│   └── theme.ts             # Colors, gradients, mock data, types
├── app.json                 # Expo config
├── eas.json                 # EAS build config
└── package.json
```

---

## 🎛️ Player Controls

| Action | How |
|---|---|
| Play/Pause | Tap play button in mini or full player |
| Next/Prev | Tap ⏮ ⏭ buttons |
| Seek | Tap on progress bar |
| Volume | Tap on volume bar in full player |
| Full player | Tap anywhere on mini player |
| Dismiss full player | Swipe down or tap ⌄ |
| Shuffle | Tap ⇄ (turns cyan when active) |
| Repeat | Tap ↺ (turns cyan when active) |
| Download | Tap ⬇ on any track |

---

## 📦 Key Dependencies

| Package | Purpose |
|---|---|
| `expo-router` | File-based navigation |
| `expo-av` | Audio playback (hook in for real FLAC) |
| `expo-linear-gradient` | Gradient artwork |
| `expo-file-system` | File downloads |
| `react-native-reanimated` | Smooth animations |
