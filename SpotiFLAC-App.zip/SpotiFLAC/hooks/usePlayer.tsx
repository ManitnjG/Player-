// hooks/usePlayer.tsx
import React, { createContext, useContext, useState, useRef, useEffect, useCallback } from 'react';
import { Track, DEMO_TRACKS } from '../constants/theme';

type PlayerContextType = {
  tracks: Track[];
  setTracks: (t: Track[]) => void;
  currentTrack: Track | null;
  currentIndex: number;
  isPlaying: boolean;
  isShuffle: boolean;
  isRepeat: boolean;
  progress: number; // 0-1
  position: number; // seconds
  duration: number; // seconds
  volume: number; // 0-1
  fullPlayerVisible: boolean;
  setFullPlayerVisible: (v: boolean) => void;
  playTrack: (track: Track, list?: Track[]) => void;
  togglePlay: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  seekTo: (pct: number) => void;
  setVolume: (v: number) => void;
  downloadQueue: DownloadItem[];
  addToQueue: (track: Track) => void;
};

type DownloadItem = {
  id: string;
  track: Track;
  progress: number;
  done: boolean;
};

const PlayerContext = createContext<PlayerContextType | null>(null);

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const [tracks, setTracks] = useState<Track[]>(DEMO_TRACKS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [progress, setProgress] = useState(0.35);
  const [volume, setVolumeState] = useState(0.7);
  const [fullPlayerVisible, setFullPlayerVisible] = useState(false);
  const [downloadQueue, setDownloadQueue] = useState<DownloadItem[]>([]);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const currentTrack = tracks[currentIndex] ?? null;

  const durationSeconds = useCallback((track: Track | null) => {
    if (!track) return 240;
    const [m, s] = track.duration.split(':').map(Number);
    return m * 60 + s;
  }, []);

  const duration = durationSeconds(currentTrack);
  const position = Math.round(progress * duration);

  const startTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setProgress(p => {
        const next = p + (1 / durationSeconds(currentTrack)) * 0.5;
        if (next >= 1) return 0;
        return next;
      });
    }, 500);
  }, [currentTrack, durationSeconds]);

  const stopTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
  }, []);

  useEffect(() => {
    if (isPlaying) startTimer(); else stopTimer();
    return stopTimer;
  }, [isPlaying, currentIndex]);

  const playTrack = useCallback((track: Track, list?: Track[]) => {
    if (list) setTracks(list);
    const idx = (list ?? tracks).findIndex(t => t.id === track.id);
    setCurrentIndex(idx >= 0 ? idx : 0);
    setProgress(0);
    setIsPlaying(true);
  }, [tracks]);

  const togglePlay = () => setIsPlaying(p => !p);

  const nextTrack = useCallback(() => {
    const list = tracks;
    if (isShuffle) {
      setCurrentIndex(Math.floor(Math.random() * list.length));
    } else {
      setCurrentIndex(i => (i + 1) % list.length);
    }
    setProgress(0);
    setIsPlaying(true);
  }, [tracks, isShuffle]);

  const prevTrack = useCallback(() => {
    if (progress > 0.05) { setProgress(0); return; }
    setCurrentIndex(i => (i - 1 + tracks.length) % tracks.length);
    setProgress(0);
    setIsPlaying(true);
  }, [tracks, progress]);

  const seekTo = (pct: number) => setProgress(Math.max(0, Math.min(1, pct)));
  const setVolume = (v: number) => setVolumeState(Math.max(0, Math.min(1, v)));

  const toggleShuffle = () => setIsShuffle(s => !s);
  const toggleRepeat = () => setIsRepeat(r => !r);

  const addToQueue = (track: Track) => {
    const item: DownloadItem = { id: Date.now().toString(), track, progress: 0, done: false };
    setDownloadQueue(q => [...q, item]);
    // Simulate download
    let p = 0;
    const iv = setInterval(() => {
      p = Math.min(p + Math.random() * 8 + 2, 100);
      setDownloadQueue(q => q.map(qi => qi.id === item.id ? { ...qi, progress: p, done: p >= 100 } : qi));
      if (p >= 100) clearInterval(iv);
    }, 200);
  };

  return (
    <PlayerContext.Provider value={{
      tracks, setTracks, currentTrack, currentIndex, isPlaying,
      isShuffle, isRepeat, progress, position, duration, volume,
      fullPlayerVisible, setFullPlayerVisible,
      playTrack, togglePlay, nextTrack, prevTrack,
      toggleShuffle, toggleRepeat, seekTo, setVolume,
      downloadQueue, addToQueue,
    }}>
      {children}
    </PlayerContext.Provider>
  );
}

export const usePlayer = () => {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error('usePlayer must be inside PlayerProvider');
  return ctx;
};
