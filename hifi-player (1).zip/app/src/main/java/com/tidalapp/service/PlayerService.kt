package com.tidalapp.service

import android.content.Intent
import android.util.Base64
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.gson.Gson
import com.tidalapp.api.RetrofitClient
import com.tidalapp.model.BtsManifest
import com.tidalapp.model.Track
import kotlinx.coroutines.*

@UnstableApi
class PlayerService : MediaSessionService() {

    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val gson = Gson()

    companion object {
        val queue = mutableListOf<Track>()
        var currentIndex = 0
        var instance: PlayerService? = null
        var onTrackChange: ((Track) -> Unit)? = null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        player = ExoPlayer.Builder(this).build().also { exo ->
            mediaSession = MediaSession.Builder(this, exo).build()
            exo.addListener(object : androidx.media3.common.Player.Listener {
                override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                    val idx = exo.currentMediaItemIndex
                    if (idx in queue.indices) {
                        currentIndex = idx
                        onTrackChange?.invoke(queue[idx])
                    }
                }
            })
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == "PLAY") {
            val track = intent.getParcelableExtra<Track>("track") ?: return START_NOT_STICKY
            val index = intent.getIntExtra("index", 0)
            loadAndPlay(track, index)
        }
        return START_NOT_STICKY
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = mediaSession

    fun loadAndPlay(track: Track, index: Int = 0) {
        scope.launch {
            val qualities = listOf("HI_RES_LOSSLESS", "LOSSLESS", "HIGH")
            for (quality in qualities) {
                try {
                    val resp = RetrofitClient.api.getStream(track.id, quality)
                    val data = resp.data ?: continue
                    val uri = resolveUri(data.manifest, data.manifestMimeType)
                    if (uri.isBlank()) continue

                    val mediaItem = MediaItem.Builder()
                        .setUri(uri)
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(track.title)
                                .setArtist(track.artistName())
                                .setAlbumTitle(track.albumTitle())
                                .setArtworkUri(
                                    track.coverUrl()?.let { android.net.Uri.parse(it) }
                                )
                                .build()
                        )
                        .build()

                    player?.apply {
                        stop()
                        clearMediaItems()
                        if (data.manifestMimeType.contains("dash+xml")) {
                            val ds = DefaultHttpDataSource.Factory()
                            val src = DashMediaSource.Factory(ds).createMediaSource(mediaItem)
                            setMediaSource(src)
                        } else {
                            setMediaItem(mediaItem)
                        }
                        prepare()
                        play()
                    }
                    onTrackChange?.invoke(track)
                    break // success
                } catch (e: Exception) {
                    // try next quality
                }
            }
        }
    }

    private fun resolveUri(manifest: String, mimeType: String): String {
        return try {
            val decoded = Base64.decode(manifest, Base64.DEFAULT)
            when {
                mimeType.contains("tidal.bts") -> {
                    val bts = gson.fromJson(String(decoded), BtsManifest::class.java)
                    bts.urls?.firstOrNull() ?: ""
                }
                mimeType.contains("dash+xml") -> {
                    "data:application/dash+xml;base64,$manifest"
                }
                else -> String(decoded)
            }
        } catch (e: Exception) { "" }
    }

    fun getPlayer() = player

    override fun onDestroy() {
        instance = null
        scope.cancel()
        mediaSession?.release()
        player?.release()
        super.onDestroy()
    }
}
