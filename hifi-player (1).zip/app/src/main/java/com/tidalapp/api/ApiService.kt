package com.tidalapp.api

import com.tidalapp.model.*
import retrofit2.http.GET
import retrofit2.http.Query

// tidal.squid.wtf proxies hifi-api at /api/
// Endpoints: /api/search/, /api/track/, /api/info/, /api/recommendations/
interface ApiService {
    @GET("api/search/")
    suspend fun searchTracks(@Query("s") query: String): SearchResponse

    @GET("api/track/")
    suspend fun getStream(
        @Query("id") id: Long,
        @Query("quality") quality: String = "HI_RES_LOSSLESS"
    ): StreamResponse

    @GET("api/info/")
    suspend fun getTrackInfo(@Query("id") id: Long): TrackResponse

    @GET("api/recommendations/")
    suspend fun getRecommendations(@Query("id") id: Long): RecommendResponse
}
