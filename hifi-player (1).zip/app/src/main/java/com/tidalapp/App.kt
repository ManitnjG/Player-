package com.tidalapp

import android.app.Application

class App : Application()
