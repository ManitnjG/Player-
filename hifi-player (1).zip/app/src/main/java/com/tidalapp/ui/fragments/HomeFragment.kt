package com.tidalapp.ui.fragments

import android.os.Bundle
import android.view.*
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tidalapp.R
import com.tidalapp.api.RetrofitClient
import com.tidalapp.ui.adapters.TrackAdapter
import com.tidalapp.ui.activities.MainActivity
import kotlinx.coroutines.*

class HomeFragment : Fragment() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View =
        inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, saved: Bundle?) {
        val rv = view.findViewById<RecyclerView>(R.id.rvTracks)
        val progress = view.findViewById<ProgressBar>(R.id.progress)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)

        val adapter = TrackAdapter { track, list, idx ->
            (activity as? MainActivity)?.playTrack(track, list, idx)
        }
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        // Load recommendations based on a popular track ID as seed
        scope.launch {
            try {
                progress.visibility = View.VISIBLE
                tvStatus.text = "Loading popular tracks…"
                // Seed with a well-known track id (Avicii - Wake Me Up)
                val resp = RetrofitClient.api.getRecommendations(36917750L)
                val tracks = resp.data?.items?.mapNotNull { it.track } ?: emptyList()
                adapter.update(tracks)
                tvStatus.text = if (tracks.isEmpty()) "No tracks found" else "Recommended"
            } catch (e: Exception) {
                tvStatus.text = "Use Search to find music"
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() { scope.cancel(); super.onDestroyView() }
}
