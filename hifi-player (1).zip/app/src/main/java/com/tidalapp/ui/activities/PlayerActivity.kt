package com.tidalapp.ui.activities

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.load
import coil.transform.RoundedCornersTransformation
import com.google.common.util.concurrent.MoreExecutors
import com.tidalapp.R
import com.tidalapp.model.Track
import com.tidalapp.service.PlayerService
import kotlinx.coroutines.*

@UnstableApi
class PlayerActivity : AppCompatActivity() {

    private var controller: MediaController? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var progressJob: Job? = null

    private lateinit var imgCover: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvQuality: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var tvElapsed: TextView
    private lateinit var tvDuration: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnShuffle: ImageButton
    private lateinit var btnRepeat: ImageButton
    private lateinit var btnBack: ImageButton

    override fun onCreate(saved: Bundle?) {
        super.onCreate(saved)
        setContentView(R.layout.activity_player)

        imgCover   = findViewById(R.id.imgCover)
        tvTitle    = findViewById(R.id.tvTitle)
        tvArtist   = findViewById(R.id.tvArtist)
        tvQuality  = findViewById(R.id.tvQuality)
        seekBar    = findViewById(R.id.seekBar)
        tvElapsed  = findViewById(R.id.tvElapsed)
        tvDuration = findViewById(R.id.tvDuration)
        btnPlay    = findViewById(R.id.btnPlay)
        btnPrev    = findViewById(R.id.btnPrev)
        btnNext    = findViewById(R.id.btnNext)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat  = findViewById(R.id.btnRepeat)
        btnBack    = findViewById(R.id.btnBack)

        btnBack.setOnClickListener { finish() }

        val track = intent.getParcelableExtra<Track>("track")
        track?.let { updateUI(it) }

        connectController()

        PlayerService.onTrackChange = { t -> runOnUiThread { updateUI(t) } }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val pos = (progress / 1000.0 * (controller?.duration ?: 0)).toLong()
                    controller?.seekTo(pos)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) { progressJob?.cancel() }
            override fun onStopTrackingTouch(sb: SeekBar) { startProgressUpdates() }
        })

        btnPlay.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        btnNext.setOnClickListener { controller?.seekToNextMediaItem() }
        btnPrev.setOnClickListener { controller?.seekToPreviousMediaItem() }
        btnShuffle.setOnClickListener {
            controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
            updateShuffleButton()
        }
        btnRepeat.setOnClickListener {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF  -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL  -> Player.REPEAT_MODE_ONE
                    else                    -> Player.REPEAT_MODE_OFF
                }
            }
            updateRepeatButton()
        }
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            controller = future.get()
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    runOnUiThread {
                        btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                        if (isPlaying) startProgressUpdates() else progressJob?.cancel()
                    }
                }
            })
            val isPlaying = controller?.isPlaying ?: false
            btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            if (isPlaying) startProgressUpdates()
        }, MoreExecutors.directExecutor())
    }

    private fun updateUI(track: Track) {
        tvTitle.text = track.title
        tvArtist.text = track.artistName()
        tvQuality.text = track.qualityBadge()
        tvDuration.text = track.duration()
        imgCover.load(track.coverUrl(640)) {
            crossfade(true)
            transformations(RoundedCornersTransformation(12f))
            placeholder(R.drawable.ic_music_placeholder)
        }
    }

    private fun startProgressUpdates() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (true) {
                delay(500)
                val c = controller ?: break
                val dur = c.duration.coerceAtLeast(1)
                val pos = c.currentPosition
                seekBar.progress = ((pos * 1000) / dur).toInt()
                tvElapsed.text = formatMs(pos)
                tvDuration.text = formatMs(dur)
            }
        }
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun updateShuffleButton() {
        val on = controller?.shuffleModeEnabled ?: false
        btnShuffle.alpha = if (on) 1f else 0.4f
    }

    private fun updateRepeatButton() {
        val icon = when (controller?.repeatMode) {
            Player.REPEAT_MODE_ONE -> R.drawable.ic_repeat_one
            Player.REPEAT_MODE_ALL -> R.drawable.ic_repeat
            else -> R.drawable.ic_repeat
        }
        btnRepeat.setImageResource(icon)
        btnRepeat.alpha = if (controller?.repeatMode == Player.REPEAT_MODE_OFF) 0.4f else 1f
    }

    override fun onDestroy() {
        progressJob?.cancel()
        scope.cancel()
        PlayerService.onTrackChange = null
        controller?.release()
        super.onDestroy()
    }
}
