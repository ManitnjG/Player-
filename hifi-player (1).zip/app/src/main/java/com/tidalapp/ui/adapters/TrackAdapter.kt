package com.tidalapp.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.RoundedCornersTransformation
import com.tidalapp.R
import com.tidalapp.model.Track

class TrackAdapter(
    private var tracks: List<Track> = emptyList(),
    private val onClick: (Track, List<Track>, Int) -> Unit
) : RecyclerView.Adapter<TrackAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cover: ImageView = v.findViewById(R.id.imgCover)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val artist: TextView = v.findViewById(R.id.tvArtist)
        val quality: TextView = v.findViewById(R.id.tvQuality)
        val duration: TextView = v.findViewById(R.id.tvDuration)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_track, parent, false))

    override fun getItemCount() = tracks.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val track = tracks[pos]
        h.title.text = track.title
        h.artist.text = track.artistName()
        h.quality.text = track.qualityBadge()
        h.duration.text = track.duration()
        h.cover.load(track.coverUrl(160)) {
            crossfade(true)
            transformations(RoundedCornersTransformation(8f))
            placeholder(R.drawable.ic_music_placeholder)
            error(R.drawable.ic_music_placeholder)
        }
        h.itemView.setOnClickListener { onClick(track, tracks, pos) }
    }

    fun update(newTracks: List<Track>) {
        tracks = newTracks
        notifyDataSetChanged()
    }
}
