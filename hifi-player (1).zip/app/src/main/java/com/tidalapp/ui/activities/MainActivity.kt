package com.tidalapp.ui.activities

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import coil.load
import coil.transform.RoundedCornersTransformation
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.common.util.concurrent.MoreExecutors
import com.tidalapp.R
import com.tidalapp.model.Track
import com.tidalapp.service.PlayerService

@UnstableApi
class MainActivity : AppCompatActivity() {

    private var controller: MediaController? = null
    private lateinit var miniPlayer: View
    private lateinit var miniCover: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlay: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navHost = supportFragmentManager.findFragmentById(R.id.navHost) as NavHostFragment
        findViewById<BottomNavigationView>(R.id.bottomNav)
            .setupWithNavController(navHost.navController)

        miniPlayer = findViewById(R.id.miniPlayer)
        miniCover  = findViewById(R.id.miniCover)
        miniTitle  = findViewById(R.id.miniTitle)
        miniArtist = findViewById(R.id.miniArtist)
        miniPlay   = findViewById(R.id.miniPlay)

        miniPlayer.setOnClickListener {
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        miniPlay.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
            updatePlayButton()
        }

        connectController()

        PlayerService.onTrackChange = { track ->
            runOnUiThread { showMiniPlayer(track) }
        }
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                try {
                    controller = future.get()
                    controller?.addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(isPlaying: Boolean) {
                            runOnUiThread { updatePlayButton() }
                        }
                    })
                } catch (_: Exception) {}
            }, MoreExecutors.directExecutor())
        }
    }

    fun playTrack(track: Track, list: List<Track> = listOf(track), index: Int = 0) {
        PlayerService.queue.clear()
        PlayerService.queue.addAll(list)
        PlayerService.currentIndex = index

        val intent = Intent(this, PlayerService::class.java).apply {
            action = "PLAY"
            putExtra("track", track)
            putExtra("index", index)
        }
        startService(intent)
        showMiniPlayer(track)

        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("track", track)
        })
    }

    private fun showMiniPlayer(track: Track) {
        miniPlayer.visibility = View.VISIBLE
        miniTitle.text = track.title
        miniArtist.text = track.artistName()
        miniCover.load(track.coverUrl(80)) {
            crossfade(true)
            transformations(RoundedCornersTransformation(6f))
            placeholder(R.drawable.ic_music_placeholder)
        }
        updatePlayButton()
    }

    private fun updatePlayButton() {
        val playing = controller?.isPlaying ?: false
        miniPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    override fun onDestroy() {
        PlayerService.onTrackChange = null
        controller?.release()
        super.onDestroy()
    }
}
