package com.tidalapp.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Track(
    val id: Long = 0,
    val title: String = "",
    val duration: Int = 0,
    val explicit: Boolean = false,
    val audioQuality: String = "",
    val artist: ArtistRef? = null,
    val artists: List<ArtistRef>? = null,
    val album: AlbumRef? = null,
    val mediaMetadata: MediaMetadata? = null
) : Parcelable {
    fun artistName() = artist?.name
        ?: artists?.firstOrNull { it.type == "MAIN" }?.name
        ?: artists?.firstOrNull()?.name
        ?: "Unknown"
    fun albumTitle() = album?.title ?: ""
    fun coverUrl(size: Int = 320) = album?.cover?.replace("-", "/")
        ?.let { "https://resources.tidal.com/images/$it/${size}x${size}.jpg" }
    fun duration() = "%d:%02d".format(duration / 60, duration % 60)
    fun qualityBadge() = when {
        mediaMetadata?.tags?.contains("HIRES_LOSSLESS") == true -> "HiRes"
        audioQuality == "LOSSLESS" -> "FLAC"
        audioQuality == "HIGH"     -> "AAC"
        else                       -> audioQuality.ifEmpty { "FLAC" }
    }
}

@Parcelize
data class ArtistRef(val id: Long = 0, val name: String = "", val type: String? = null, val picture: String? = null) : Parcelable {
    fun pictureUrl(size: Int = 320) = picture?.replace("-", "/")
        ?.let { "https://resources.tidal.com/images/$it/${size}x${size}.jpg" }
}

@Parcelize
data class AlbumRef(val id: Long = 0, val title: String = "", val cover: String? = null) : Parcelable

@Parcelize
data class MediaMetadata(val tags: List<String>? = null) : Parcelable

// API response wrappers
data class SearchResponse(val version: String = "", val data: SearchData? = null)
data class SearchData(val limit: Int = 0, val totalNumberOfItems: Int = 0, val items: List<Track> = emptyList())

data class StreamResponse(val version: String = "", val data: StreamData? = null)
data class StreamData(
    val trackId: Long = 0,
    val audioQuality: String = "",
    val manifestMimeType: String = "",
    val manifest: String = "",
    val bitDepth: Int? = null,
    val sampleRate: Int? = null
)

data class TrackResponse(val version: String = "", val data: Track? = null)
data class RecommendResponse(val version: String = "", val data: RecommendData? = null)
data class RecommendData(val items: List<RecommendItem> = emptyList())
data class RecommendItem(val track: Track? = null)

data class BtsManifest(val mimeType: String? = null, val codecs: String? = null, val urls: List<String>? = null)
