package com.tidalapp.api

import com.tidalapp.model.*
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("api/proxy/search/")
    suspend fun searchTracks(@Query("s") query: String): SearchResponse

    @GET("api/proxy/search/")
    suspend fun searchArtists(@Query("a") query: String): SearchResponse

    @GET("api/proxy/track/")
    suspend fun getStream(
        @Query("id") id: Long,
        @Query("quality") quality: String = "HI_RES_LOSSLESS"
    ): StreamResponse

    @GET("api/proxy/info/")
    suspend fun getTrackInfo(@Query("id") id: Long): TrackResponse

    @GET("api/proxy/recommendations/")
    suspend fun getRecommendations(@Query("id") id: Long): RecommendResponse
}
