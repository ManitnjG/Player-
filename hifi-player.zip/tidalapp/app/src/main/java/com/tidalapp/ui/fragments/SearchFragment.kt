package com.tidalapp.ui.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tidalapp.R
import com.tidalapp.api.RetrofitClient
import com.tidalapp.ui.adapters.TrackAdapter
import com.tidalapp.ui.activities.MainActivity
import kotlinx.coroutines.*

class SearchFragment : Fragment() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var searchJob: Job? = null
    private lateinit var adapter: TrackAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View =
        inflater.inflate(R.layout.fragment_search, container, false)

    override fun onViewCreated(view: View, saved: Bundle?) {
        val etSearch = view.findViewById<EditText>(R.id.etSearch)
        val rv = view.findViewById<RecyclerView>(R.id.rvResults)
        val progress = view.findViewById<ProgressBar>(R.id.progress)
        val tvEmpty = view.findViewById<TextView>(R.id.tvEmpty)

        adapter = TrackAdapter { track, list, idx ->
            (activity as? MainActivity)?.playTrack(track, list, idx)
        }
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                searchJob?.cancel()
                val q = s?.toString()?.trim() ?: return
                if (q.length < 2) { adapter.update(emptyList()); tvEmpty.visibility = View.GONE; return }
                searchJob = scope.launch {
                    delay(400)
                    progress.visibility = View.VISIBLE
                    tvEmpty.visibility = View.GONE
                    try {
                        val resp = RetrofitClient.api.searchTracks(q)
                        val items = resp.data?.items ?: emptyList()
                        adapter.update(items)
                        tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                        tvEmpty.text = "No results for \"$q\""
                    } catch (e: Exception) {
                        tvEmpty.text = "Search failed: ${e.message}"
                        tvEmpty.visibility = View.VISIBLE
                    } finally {
                        progress.visibility = View.GONE
                    }
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    override fun onDestroyView() { scope.cancel(); super.onDestroyView() }
}
